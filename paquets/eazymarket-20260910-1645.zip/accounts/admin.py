from django.contrib import admin

from .models import UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "user_type", "phone", "country", "city", "is_verified",
                    "store_name", "unlimited_slots", "is_official")
    list_filter = ("user_type", "country", "is_verified", "is_store_active", "unlimited_slots")
    search_fields = ("user__username", "user__email", "phone", "store_name")
    list_editable = ("is_verified", "unlimited_slots", "is_official")
    list_select_related = ("user", "country")
