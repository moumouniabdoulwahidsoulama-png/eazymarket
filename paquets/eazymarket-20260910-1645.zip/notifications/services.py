"""
Envoi des notifications, tous canaux.

Une seule fonction à appeler dans le reste de l'application : `notifier()`.
Elle écrit la notification dans l'application, et pour ce qui est urgent
— une commande à confirmer, un paiement reçu — envoie aussi un SMS.

L'e-mail n'est jamais le canal principal : au Burkina Faso, un commerçant
lit ses SMS, pas sa boîte mail.
"""

import logging

from django.conf import settings

from .models import Notification
from .providers import get_sms_provider

logger = logging.getLogger("notifications")


def _numero_de(user):
    profil = getattr(user, "profile", None)
    if profil is None:
        return ""
    return (profil.whatsapp or profil.phone or "").strip()


def notifier(user, titre, message, lien="", urgent=False, sms_texte=None):
    """Notifie un utilisateur. Retourne la Notification créée.

    urgent=True déclenche l'envoi d'un SMS si un fournisseur est configuré
    et si l'utilisateur a un numéro.
    """
    notification = Notification.objects.create(
        user=user, title=titre, message=message, link=lien, is_urgent=urgent
    )

    if not urgent or not settings.NOTIFICATIONS.get("SMS_ENABLED", True):
        return notification

    numero = _numero_de(user)
    if not numero:
        notification.sms_detail = "Aucun numéro de téléphone au profil"
        notification.save(update_fields=["sms_detail"])
        return notification

    texte = sms_texte or f"{titre} : {message}"
    if lien:
        base = settings.PAYMENTS.get("PUBLIC_BASE_URL", "").rstrip("/")
        texte = f"{texte} {base}{lien}"

    resultat = get_sms_provider().send(numero, texte)
    notification.sms_status = (
        Notification.Sms.SENT if resultat.ok else Notification.Sms.FAILED
    )
    notification.sms_detail = resultat.message[:250]
    notification.save(update_fields=["sms_status", "sms_detail"])

    if not resultat.ok:
        logger.warning("SMS non délivré à %s : %s", user, resultat.message)
    return notification


def notifier_par_lot(utilisateurs, titre, message, lien="", urgent=False):
    return [notifier(u, titre, message, lien, urgent) for u in utilisateurs]
