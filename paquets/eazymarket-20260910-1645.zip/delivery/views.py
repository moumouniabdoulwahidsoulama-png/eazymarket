"""Dossier de validation des livreurs."""

from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import DeliveryReferral, Sponsor


def _referral(user):
    referral, _ = DeliveryReferral.objects.get_or_create(deliverer=user)
    return referral


@login_required
def referral_dashboard(request):
    if not request.user.profile.can_deliver:
        return redirect("become_delivery")
    referral = _referral(request.user)
    return render(
        request,
        "delivery/referral_dashboard.html",
        {"referral": referral, "sponsors": referral.sponsors.all()},
    )


@login_required
@require_POST
def add_sponsor(request):
    if not request.user.profile.can_deliver:
        return redirect("become_delivery")
    referral = _referral(request.user)

    if referral.status == DeliveryReferral.Status.VERIFIED:
        messages.info(request, "Votre dossier est déjà validé.")
        return redirect("referral_dashboard")

    full_name = request.POST.get("full_name", "").strip()
    phone = request.POST.get("phone", "").strip()
    if len(full_name) < 3 or len(phone) < 8:
        messages.error(request, "Indiquez un nom complet et un numéro joignable.")
    elif referral.sponsors.filter(phone=phone).exists():
        messages.error(request, "Ce numéro figure déjà dans votre dossier.")
    else:
        Sponsor.objects.create(
            referral=referral,
            full_name=full_name,
            phone=phone,
            relation=request.POST.get("relation", "").strip(),
        )
        messages.success(request, f"{full_name} ajouté à votre dossier.")
    return redirect("referral_dashboard")


@login_required
@require_POST
def remove_sponsor(request, sponsor_id):
    sponsor = get_object_or_404(Sponsor, id=sponsor_id, referral__deliverer=request.user)
    if sponsor.referral.status == DeliveryReferral.Status.VERIFIED:
        messages.error(request, "Un dossier validé ne peut plus être modifié.")
    else:
        sponsor.delete()
        messages.info(request, "Répondant retiré.")
    return redirect("referral_dashboard")


@login_required
@require_POST
def submit_referral(request):
    if not request.user.profile.can_deliver:
        return redirect("become_delivery")
    referral = _referral(request.user)

    if "id_document" in request.FILES:
        referral.id_document = request.FILES["id_document"]

    if not referral.is_complete:
        messages.error(
            request,
            f"Il vous manque encore {referral.missing} répondant"
            f"{'s' if referral.missing > 1 else ''}.",
        )
        referral.save()
        return redirect("referral_dashboard")

    referral.status = DeliveryReferral.Status.SUBMITTED
    from django.utils import timezone

    referral.submitted_at = timezone.now()
    referral.save()
    messages.success(
        request,
        "Dossier envoyé. Nous appelons vos répondants et vous activons sous 48 h.",
    )
    return redirect("referral_dashboard")


@staff_member_required
def referral_list(request):
    return render(
        request,
        "delivery/referral_list.html",
        {
            "submitted": DeliveryReferral.objects.filter(status="submitted").prefetch_related("sponsors"),
            "drafts": DeliveryReferral.objects.filter(status="draft"),
            "verified": DeliveryReferral.objects.filter(status="verified")[:20],
        },
    )


@staff_member_required
@require_POST
def verify_referral(request, referral_id):
    referral = get_object_or_404(DeliveryReferral, id=referral_id)
    action = request.POST.get("action")
    referral.note = request.POST.get("note", referral.note)

    if action == "approve":
        referral.mark_verified(by=request.user)
        messages.success(request, f"Livreur {referral.deliverer.username} validé.")
    elif action == "reject":
        referral.status = DeliveryReferral.Status.REJECTED
        referral.save()
        messages.warning(request, f"Dossier de {referral.deliverer.username} refusé.")

    try:
        from notifications.services import notifier

        notifier(
            referral.deliverer,
            "Dossier livreur" if action != "approve" else "Vous êtes validé !",
            "Votre dossier a été validé, vous pouvez accepter des courses."
            if action == "approve"
            else "Votre dossier n'a pas pu être validé. Contactez-nous pour en savoir plus.",
            lien="/livraison/mon-dossier/",
            urgent=True,
        )
    except Exception:  # noqa: BLE001
        pass
    return redirect("referral_list")
