"""
Configuration Django — EazyMarket
Marketplace produits + services (Burkina Faso).

Tout ce qui est sensible ou dépend de l'environnement se lit dans un
fichier .env à la racine du projet (voir .env.example). Aucune clé ne
doit être écrite en dur dans ce fichier.
"""

import os
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


# ---------------------------------------------------------------------
# Petit lecteur de .env (évite une dépendance externe)
# ---------------------------------------------------------------------
def _load_dotenv(path):
    if not path.exists():
        return
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip()
        # Commentaire de fin de ligne : on coupe sur " #" (un # collé à la
        # valeur est conservé — le code USSD se termine par #)
        cut = re.split(r"\s+#", value, maxsplit=1)[0]
        os.environ.setdefault(key.strip(), cut.strip().strip("'\""))


_load_dotenv(BASE_DIR / ".env")


def env(key, default=None):
    return os.environ.get(key, default)


def env_bool(key, default=False):
    return str(env(key, str(default))).lower() in ("1", "true", "yes", "on")


def env_list(key, default=""):
    return [v.strip() for v in env(key, default).split(",") if v.strip()]


# ---------------------------------------------------------------------
# Sécurité
# ---------------------------------------------------------------------
SECRET_KEY = env(
    "DJANGO_SECRET_KEY",
    "dev-only-key-change-me-in-production-0000000000000000000000",
)

DEBUG = env_bool("DJANGO_DEBUG", True)

ALLOWED_HOSTS = env_list("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1,[::1]")
if DEBUG:
    # En développement on autorise aussi l'IP locale (test depuis un téléphone)
    ALLOWED_HOSTS += [".localhost", "0.0.0.0", "testserver"]
    try:
        import socket

        _host = socket.gethostname()
        ALLOWED_HOSTS += [_host, socket.gethostbyname(_host)]
    except Exception:  # pragma: no cover - dépend de la machine
        pass

CSRF_TRUSTED_ORIGINS = env_list("DJANGO_CSRF_TRUSTED_ORIGINS")


# ---------------------------------------------------------------------
# Applications
# ---------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "django.contrib.humanize",
    # Applications métier
    "regions",
    "accounts",
    "products",
    "cart",
    "orders",
    "services",
    "payments",
    "delivery",
    "notifications",
    "pages",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# WhiteNoise est optionnel : s'il n'est pas installé on le retire silencieusement
try:  # pragma: no cover
    import whitenoise  # noqa: F401
except ImportError:  # pragma: no cover
    MIDDLEWARE.remove("whitenoise.middleware.WhiteNoiseMiddleware")

ROOT_URLCONF = "EazyMarket.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "EazyMarket.context_processors.site_context",
            ],
        },
    },
]

WSGI_APPLICATION = "EazyMarket.wsgi.application"
ASGI_APPLICATION = "EazyMarket.asgi.application"


# ---------------------------------------------------------------------
# Base de données
# ---------------------------------------------------------------------
DB_ENGINE = env("DB_ENGINE", "sqlite").lower()

if DB_ENGINE in ("mysql", "mariadb"):
    # Base native de cPanel. Le pilote PyMySQL (voir EazyMarket/__init__.py)
    # s'installe sans compilation, contrairement à mysqlclient.
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.mysql",
            "NAME": env("DB_NAME", ""),
            "USER": env("DB_USER", ""),
            "PASSWORD": env("DB_PASSWORD", ""),
            "HOST": env("DB_HOST", "localhost"),
            "PORT": env("DB_PORT", "3306"),
            "CONN_MAX_AGE": 60,
            "OPTIONS": {
                "charset": "utf8mb4",
                "init_command": "SET sql_mode='STRICT_TRANS_TABLES'",
            },
        }
    }
elif DB_ENGINE in ("postgresql", "postgres"):
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.postgresql",
            "NAME": env("DB_NAME", "eazymarket"),
            "USER": env("DB_USER", "eazymarket"),
            "PASSWORD": env("DB_PASSWORD", ""),
            "HOST": env("DB_HOST", "localhost"),
            "PORT": env("DB_PORT", "5432"),
            "CONN_MAX_AGE": 60,
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "db.sqlite3",
            "OPTIONS": {"timeout": 20},
        }
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# ---------------------------------------------------------------------
# Authentification
# ---------------------------------------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
        "OPTIONS": {"min_length": 8},
    },
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "home"
LOGOUT_REDIRECT_URL = "home"

SESSION_COOKIE_AGE = 60 * 60 * 24 * 14  # 14 jours
SESSION_SAVE_EVERY_REQUEST = True


# ---------------------------------------------------------------------
# Internationalisation
# ---------------------------------------------------------------------
LANGUAGE_CODE = "fr-fr"
TIME_ZONE = "Africa/Ouagadougou"
USE_I18N = True
USE_TZ = True


# ---------------------------------------------------------------------
# Fichiers statiques et médias
# ---------------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]

# En production sur cPanel, on place les fichiers servis par Apache dans le
# dossier public du sous-domaine : DJANGO_STATIC_ROOT et DJANGO_MEDIA_ROOT
# pointent alors vers ~/le-sous-domaine/static et .../media.
STATIC_ROOT = Path(env("DJANGO_STATIC_ROOT", str(BASE_DIR / "staticfiles")))

MEDIA_URL = "/media/"
MEDIA_ROOT = Path(env("DJANGO_MEDIA_ROOT", str(BASE_DIR / "media")))
MEDIA_ROOT.mkdir(parents=True, exist_ok=True)

# Filet de sécurité : sur un hébergement mutualisé, Apache ne sert pas toujours
# /media/ directement. Laissé à True, Django s'en charge lui-même — un peu moins
# rapide, mais les photos s'affichent toujours. À passer à False une fois le
# .htaccess « PassengerEnabled off » en place dans le dossier des médias.
SERVE_MEDIA = env_bool("DJANGO_SERVE_MEDIA", True)

STORAGES = {
    "default": {"BACKEND": "django.core.files.storage.FileSystemStorage"},
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage"
        if not DEBUG and "whitenoise.middleware.WhiteNoiseMiddleware" in MIDDLEWARE
        else "django.contrib.staticfiles.storage.StaticFilesStorage"
    },
}

# Taille maximale des images envoyées (5 Mo)
DATA_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024
FILE_UPLOAD_MAX_MEMORY_SIZE = 5 * 1024 * 1024


# ---------------------------------------------------------------------
# E-mail
# ---------------------------------------------------------------------
EMAIL_BACKEND = env(
    "EMAIL_BACKEND",
    "django.core.mail.backends.console.EmailBackend"
    if DEBUG
    else "django.core.mail.backends.smtp.EmailBackend",
)
EMAIL_HOST = env("EMAIL_HOST", "")
EMAIL_PORT = int(env("EMAIL_PORT", "587"))
EMAIL_USE_TLS = env_bool("EMAIL_USE_TLS", True)
EMAIL_HOST_USER = env("EMAIL_HOST_USER", "")
EMAIL_HOST_PASSWORD = env("EMAIL_HOST_PASSWORD", "")
DEFAULT_FROM_EMAIL = env("DEFAULT_FROM_EMAIL", "EazyMarket <no-reply@eazymarket.bf>")
CONTACT_EMAIL = env("CONTACT_EMAIL", "contact@eazymarket.bf")


# ---------------------------------------------------------------------
# Paramètres métier EazyMarket
# ---------------------------------------------------------------------
EAZYMARKET = {
    # Identité
    "SITE_NAME": env("SITE_NAME", "EazyMarket"),
    "SITE_TAGLINE": env("SITE_TAGLINE", "Achetez. Trouvez un pro. Au même endroit."),
    "CURRENCY": "FCFA",
    "COUNTRY": env("SITE_COUNTRY", "Burkina Faso"),
    "CITY": env("SITE_CITY", "Ouagadougou"),
    "SUPPORT_PHONE": env("SUPPORT_PHONE", "+226 64 69 12 08"),
    "SUPPORT_EMAIL": CONTACT_EMAIL,
    "WHATSAPP": env("SUPPORT_WHATSAPP", "22664691208"),
    # Deuxième ligne : quand la première ne répond pas
    "SUPPORT_PHONE_2": env("SUPPORT_PHONE_2", "+226 77 55 20 87"),
    "WHATSAPP_2": env("SUPPORT_WHATSAPP_2", "22677552087"),

    # ---- Boutique : emplacements produits ----
    # Le vendeur dispose d'emplacements. Les premiers sont offerts, ensuite il
    # achète des packs. Un emplacement = une annonce en ligne.
    "SHOP_FREE_SLOTS": int(env("SHOP_FREE_SLOTS", "2")),
    "SHOP_PACK_SIZE": int(env("SHOP_PACK_SIZE", "10")),
    "SHOP_PACK_PRICE": int(env("SHOP_PACK_PRICE", "5000")),

    # ---- Boutique : commission sur les ventes ----
    # Le vendeur saisit ce qu'il veut toucher. La commission est ajoutée
    # par-dessus, puis le prix affiché est ARRONDI au palier supérieur pour
    # rester lisible (1 000 F → 1 100 F, jamais 1 050 F).
    "COMMISSION_RATE": float(env("COMMISSION_RATE", "5")),
    "COMMISSION_MIN": int(env("COMMISSION_MIN", "100")),
    # (seuil de prix, palier d'arrondi) — appliqué du plus petit au plus grand
    "PRICE_STEPS": [(10000, 100), (50000, 100), (200000, 500), (10**9, 1000)],

    # ---- Services : abonnement artisan ----
    "ARTISAN_SUB_PRICE": int(env("ARTISAN_SUB_PRICE", "1000")),
    "ARTISAN_SUB_DAYS": int(env("ARTISAN_SUB_DAYS", "60")),
    # Mettre à True pour une opération de lancement (profils visibles sans payer)
    "ARTISAN_FREE_LAUNCH": env_bool("ARTISAN_FREE_LAUNCH", False),
    "ARTISAN_BOOST_PRICE": int(env("ARTISAN_BOOST_PRICE", "2000")),
    "ARTISAN_BOOST_DAYS": int(env("ARTISAN_BOOST_DAYS", "7")),

    # ---- Services : déblocage du contact par le client ----
    "CONTACT_UNLOCK_PRICE": int(env("CONTACT_UNLOCK_PRICE", "200")),
    "CONTACT_UNLOCK_DAYS": int(env("CONTACT_UNLOCK_DAYS", "90")),
    # Nombre de contacts offerts à chaque nouveau client (pour amorcer l'usage)
    "CONTACT_FREE_UNLOCKS": int(env("CONTACT_FREE_UNLOCKS", "1")),

    # ---- Livreurs ----
    # Un livreur est activé après avoir parrainé N personnes, puis validation admin
    "DELIVERY_REQUIRED_SHARES": int(env("DELIVERY_REQUIRED_SHARES", "3")),

    # ---- Livraison ----
    "DELIVERY_FEE_CITY": int(env("DELIVERY_FEE_CITY", "1000")),
    "DELIVERY_FEE_OUT": int(env("DELIVERY_FEE_OUT", "2500")),
    "FREE_DELIVERY_FROM": int(env("FREE_DELIVERY_FROM", "50000")),

    # ---- Reversement aux vendeurs ----
    "PAYOUT_MIN": int(env("PAYOUT_MIN", "5000")),
    "PAYOUT_DELAY_DAYS": int(env("PAYOUT_DELAY_DAYS", "3")),
}


# ---------------------------------------------------------------------
# Paiements (mobile money)
# ---------------------------------------------------------------------
PAYMENTS = {
    # Fournisseur actif : "manual" | "cinetpay"
    "PROVIDER": env("PAYMENT_PROVIDER", "manual"),

    # --- Encaissement manuel sur vos numéros marchands ---
    # Le client compose *144*10*NUMERO*MONTANT# puis valide avec son code.
    "MANUAL": {
        "USSD_TEMPLATE": env("ORANGE_USSD_TEMPLATE", "*144*10*{numero}*{montant}#"),
        "ACCOUNTS": [
            {
                "id": "om1",
                "label": "Orange Money",
                "number": env("ORANGE_MONEY_NUMBER_1", ""),
                "name": env("ORANGE_MONEY_NAME", ""),
                "whatsapp": env("ORANGE_MONEY_WHATSAPP_1", ""),
            },
            {
                "id": "om2",
                "label": "Orange Money (2ᵉ numéro)",
                "number": env("ORANGE_MONEY_NUMBER_2", ""),
                "name": env("ORANGE_MONEY_NAME", ""),
                "whatsapp": "",
            },
        ],
        "HOLDER": env("ORANGE_MONEY_NAME", ""),
        "MOOV_MONEY_NUMBER": env("MOOV_MONEY_NUMBER", ""),
        "MOOV_MONEY_WHATSAPP": env("MOOV_MONEY_WHATSAPP", ""),
        "WAVE_NUMBER": env("WAVE_NUMBER", ""),
        "WAVE_WHATSAPP": env("WAVE_WHATSAPP", ""),
    },

    # --- Agrégateur CinetPay (Orange, Moov, Wave, cartes) ---
    "CINETPAY": {
        "API_KEY": env("CINETPAY_API_KEY", ""),
        "SITE_ID": env("CINETPAY_SITE_ID", ""),
        "SECRET_KEY": env("CINETPAY_SECRET_KEY", ""),
        "BASE_URL": env("CINETPAY_BASE_URL", "https://api-checkout.cinetpay.com/v2"),
    },
    "PUBLIC_BASE_URL": env("PUBLIC_BASE_URL", "http://127.0.0.1:8000"),
}


# ---------------------------------------------------------------------
# Journalisation
# ---------------------------------------------------------------------
LOG_DIR = Path(env("DJANGO_LOG_DIR", str(BASE_DIR / "logs")))
LOG_DIR.mkdir(parents=True, exist_ok=True)

LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {"format": "{levelname} {asctime} {name} {message}", "style": "{"},
    },
    "handlers": {
        "console": {"class": "logging.StreamHandler", "formatter": "verbose"},
        "file": {
            "class": "logging.handlers.RotatingFileHandler",
            "filename": LOG_DIR / "eazymarket.log",
            "maxBytes": 2 * 1024 * 1024,
            "backupCount": 3,
            "formatter": "verbose",
            "encoding": "utf-8",
        },
    },
    "root": {"handlers": ["console", "file"], "level": "INFO"},
    "loggers": {
        "django.request": {"handlers": ["console", "file"], "level": "ERROR", "propagate": False},
        "payments": {"handlers": ["console", "file"], "level": "INFO", "propagate": False},
    },
}


# ---------------------------------------------------------------------
# Durcissement en production
# ---------------------------------------------------------------------
if not DEBUG:
    SECURE_SSL_REDIRECT = env_bool("SECURE_SSL_REDIRECT", True)
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = int(env("SECURE_HSTS_SECONDS", str(60 * 60 * 24 * 30)))
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    SECURE_CONTENT_TYPE_NOSNIFF = True
    SECURE_REFERRER_POLICY = "same-origin"
    X_FRAME_OPTIONS = "DENY"
    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")

MESSAGE_STORAGE = "django.contrib.messages.storage.session.SessionStorage"
