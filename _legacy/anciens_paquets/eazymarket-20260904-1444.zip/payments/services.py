"""
Logique métier des paiements : c'est ici — et nulle part ailleurs —
qu'une commande devient « payée » et qu'un vendeur est crédité.
"""

import logging
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.db import transaction as db_transaction
from django.utils import timezone

from .models import Payout, Transaction, Wallet, WalletEntry

logger = logging.getLogger("payments")


def get_wallet(user):
    wallet, _ = Wallet.objects.get_or_create(user=user)
    return wallet


def start_transaction(*, user, purpose, amount, channel="", obj=None, payer_number=""):
    """Crée une transaction en attente pour un objet métier."""
    tx = Transaction.objects.create(
        user=user,
        purpose=purpose,
        amount=Decimal(int(amount)),
        channel=channel,
        payer_number=payer_number,
        object_type=obj.__class__.__name__.lower() if obj is not None else "",
        object_id=getattr(obj, "pk", None),
    )
    return tx


@db_transaction.atomic
def confirm_transaction(tx, *, by=None):
    """Confirme une transaction et déclenche l'effet métier correspondant.

    Idempotent : appeler deux fois ne crédite pas deux fois.
    """
    if tx.status == Transaction.Status.SUCCESS:
        return tx

    tx.status = Transaction.Status.SUCCESS
    tx.confirmed_at = timezone.now()
    tx.reviewed_by = by
    tx.save(update_fields=["status", "confirmed_at", "reviewed_by", "updated_at"])

    if tx.purpose == Transaction.Purpose.ORDER:
        _settle_order(tx)
    elif tx.purpose == Transaction.Purpose.SUBSCRIPTION:
        _activate_subscription(tx)
    elif tx.purpose == Transaction.Purpose.SHOP_PACK:
        _add_shop_slots(tx)
    elif tx.purpose == Transaction.Purpose.CONTACT:
        _unlock_contact(tx)
    elif tx.purpose == Transaction.Purpose.BOOST:
        _activate_boost(tx)

    logger.info("Transaction confirmée %s (%s FCFA)", tx.reference, tx.amount)
    return tx


def reject_transaction(tx, *, by=None, reason=""):
    tx.status = Transaction.Status.FAILED
    tx.reviewed_by = by
    tx.notes = (tx.notes + "\n" + reason).strip()
    tx.save(update_fields=["status", "reviewed_by", "notes", "updated_at"])
    return tx


# ---------------------------------------------------------------------
# Effets métier
# ---------------------------------------------------------------------
def _settle_order(tx):
    """Marque la commande payée, décrémente le stock, crédite les vendeurs."""
    from orders.models import Order

    try:
        order = Order.objects.select_for_update().get(pk=tx.object_id)
    except Order.DoesNotExist:
        logger.error("Transaction %s : commande %s introuvable", tx.reference, tx.object_id)
        return

    if order.is_paid:
        return

    order.is_paid = True
    order.paid_at = timezone.now()
    order.status = Order.Status.PAID
    order.payment_method = tx.get_channel_display() or tx.provider
    order.payment_reference = tx.reference
    order.save()

    release_at = timezone.now() + timedelta(days=settings.EAZYMARKET["PAYOUT_DELAY_DAYS"])

    for item in order.items.select_related("product", "seller"):
        product = item.product
        if product:
            product.stock = max(0, product.stock - item.quantity)
            product.sold_count = (product.sold_count or 0) + item.quantity
            if product.stock == 0:
                product.is_available = False
            product.save(update_fields=["stock", "sold_count", "is_available"])

        if item.seller_id:
            wallet = get_wallet(item.seller)
            net = item.subtotal - item.commission
            WalletEntry.objects.create(
                wallet=wallet,
                kind=WalletEntry.Kind.SALE,
                amount=net,
                label=f"Vente {item.quantity}× {item.product_name} (cmd {order.order_number})",
                is_released=False,
                release_at=release_at,
                order=order,
            )


def _activate_subscription(tx):
    """Active ou prolonge l'abonnement d'un artisan (2 mois par défaut)."""
    from services.models import Artisan

    artisan = Artisan.objects.filter(user=tx.user).first()
    if not artisan:
        logger.error("Transaction %s : artisan introuvable", tx.reference)
        return

    periods = int((tx.raw_response or {}).get("periods", 1) or 1)
    days = settings.EAZYMARKET["ARTISAN_SUB_DAYS"] * periods
    artisan.activate_subscription(plan="pro", days=days)


def _add_shop_slots(tx):
    """Crédite un pack d'emplacements d'annonces à un vendeur."""
    from accounts.models import UserProfile

    profile = UserProfile.objects.filter(user=tx.user).first()
    if not profile:
        logger.error("Transaction %s : profil introuvable", tx.reference)
        return

    packs = int((tx.raw_response or {}).get("packs", 1) or 1)
    profile.extra_slots += settings.EAZYMARKET["SHOP_PACK_SIZE"] * packs
    profile.is_store_active = True
    profile.save(update_fields=["extra_slots", "is_store_active"])


def _unlock_contact(tx):
    """Ouvre l'accès au numéro d'un artisan pour ce client."""
    from services.models import Artisan, ContactUnlock

    artisan = Artisan.objects.filter(pk=tx.object_id).first()
    if not artisan:
        logger.error("Transaction %s : artisan %s introuvable", tx.reference, tx.object_id)
        return

    ContactUnlock.objects.update_or_create(
        client=tx.user,
        artisan=artisan,
        defaults={
            "amount": tx.amount,
            "is_free": False,
            "transaction_reference": tx.reference,
            "expires_at": timezone.now()
            + timedelta(days=settings.EAZYMARKET["CONTACT_UNLOCK_DAYS"]),
        },
    )
    Artisan.objects.filter(pk=artisan.pk).update(contact_views=artisan.contact_views + 1)


def _activate_boost(tx):
    from services.models import Artisan

    artisan = Artisan.objects.filter(user=tx.user).first()
    if artisan:
        artisan.is_featured = True
        artisan.featured_until = timezone.now() + timedelta(
            days=settings.EAZYMARKET["ARTISAN_BOOST_DAYS"]
        )
        artisan.save(update_fields=["is_featured", "featured_until"])


# ---------------------------------------------------------------------
# Portefeuilles
# ---------------------------------------------------------------------
def release_due_entries():
    """Libère les gains dont le délai de sécurité est écoulé.

    À lancer une fois par jour : python manage.py liberer_gains
    """
    now = timezone.now()
    qs = WalletEntry.objects.filter(is_released=False, release_at__lte=now)
    count = qs.update(is_released=True)
    if count:
        logger.info("%s écriture(s) de portefeuille libérée(s)", count)
    return count


def request_payout(user, amount=None):
    """Crée une demande de retrait. Retourne (payout|None, message)."""
    wallet = get_wallet(user)
    minimum = settings.EAZYMARKET["PAYOUT_MIN"]

    if not wallet.payout_number:
        return None, "Enregistrez d'abord votre numéro mobile money de retrait."

    amount = Decimal(int(amount)) if amount else wallet.available
    if amount <= 0:
        return None, "Aucun montant disponible."
    if amount < minimum:
        return None, f"Le retrait minimum est de {minimum:,.0f} FCFA.".replace(",", " ")
    if amount > wallet.available:
        return None, "Montant supérieur à votre solde disponible."
    if wallet.payouts.filter(status__in=[Payout.Status.REQUESTED, Payout.Status.PROCESSING]).exists():
        return None, "Une demande de retrait est déjà en cours."

    payout = Payout.objects.create(
        wallet=wallet,
        amount=amount,
        channel=wallet.payout_channel,
        number=wallet.payout_number,
    )
    return payout, "Demande enregistrée. Le versement intervient sous 48 h ouvrées."
