"""
Toutes les étapes serveur en une seule commande.

    python deploiement/mise_en_ligne.py

À lancer depuis le dossier de l'application, avec l'environnement virtuel
activé — ou à coller dans cPanel → Setup Python App → « Execute python script ».

Enchaîne : migrations → catalogue → fichiers statiques → vérification.
Sans risque : rien n'écrase de données existantes, la commande peut être
relancée autant de fois que nécessaire.
"""

import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "EazyMarket.settings")

import django  # noqa: E402

django.setup()

from django.core.management import call_command  # noqa: E402

from django.conf import settings  # noqa: E402


def _encodage_mysql():
    """Sur MySQL, la base doit accepter les emoji avant d'insérer les drapeaux."""
    if "mysql" in settings.DATABASES["default"]["ENGINE"]:
        call_command("reparer_utf8mb4")
    else:
        print("        base non-MySQL : rien à faire.")


ETAPES = [
    ("Application des migrations", lambda: call_command("migrate", interactive=False)),
    ("Encodage de la base (emoji, accents)", _encodage_mysql),
    ("Pays, rayons et métiers", lambda: call_command("init_catalogue")),
    ("Rassemblement des fichiers statiques",
     lambda: call_command("collectstatic", interactive=False, clear=True, verbosity=0)),
]


def main():
    print()
    print("Mise en ligne d'EazyMarket")
    print("=" * 62)
    for numero, (titre, action) in enumerate(ETAPES, start=1):
        print(f"\n[{numero}/{len(ETAPES)}] {titre}…")
        try:
            action()
            print("        terminé.")
        except Exception as exc:  # noqa: BLE001
            print(f"        ÉCHEC : {exc}")
            print("\nCorrigez cette erreur avant de continuer.")
            sys.exit(1)

    print("\n" + "=" * 62)
    call_command("verifier_production")
    print("S'il manque un compte administrateur :")
    print("    python manage.py createsuperuser")
    print("Puis redémarrez l'application dans cPanel (bouton RESTART).")
    print()


if __name__ == "__main__":
    main()
