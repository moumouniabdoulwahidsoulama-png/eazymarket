/* =========================================================
   EazyMarket — interactions de base (aucune dépendance)
   ========================================================= */
(function () {
  'use strict';

  /* ---- Menu mobile ---- */
  var toggle = document.querySelector('[data-nav-toggle]');
  var links = document.querySelector('[data-nav-links]');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* ---- Menus déroulants ---- */
  document.querySelectorAll('[data-dropdown]').forEach(function (dd) {
    var btn = dd.querySelector('[data-dropdown-btn]');
    if (!btn) return;
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var wasOpen = dd.classList.contains('open');
      document.querySelectorAll('[data-dropdown].open').forEach(function (o) { o.classList.remove('open'); });
      if (!wasOpen) dd.classList.add('open');
    });
  });
  document.addEventListener('click', function () {
    document.querySelectorAll('[data-dropdown].open').forEach(function (o) { o.classList.remove('open'); });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      document.querySelectorAll('[data-dropdown].open').forEach(function (o) { o.classList.remove('open'); });
    }
  });

  /* ---- Sélecteur de quantité ---- */
  document.querySelectorAll('[data-qty]').forEach(function (box) {
    var input = box.querySelector('input');
    box.querySelectorAll('[data-qty-step]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var step = parseInt(btn.getAttribute('data-qty-step'), 10);
        var max = parseInt(input.getAttribute('max') || '9999', 10);
        var val = (parseInt(input.value, 10) || 1) + step;
        input.value = Math.min(max, Math.max(1, val));
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    });
  });

  /* ---- Champs conditionnels du formulaire d'inscription ---- */
  var roleInputs = document.querySelectorAll('[data-role-input]');
  if (roleInputs.length) {
    var applyRole = function () {
      var checked = document.querySelector('[data-role-input]:checked');
      var role = checked ? checked.value : 'buyer';
      document.querySelectorAll('[data-role-block]').forEach(function (block) {
        var roles = block.getAttribute('data-role-block').split(',');
        block.classList.toggle('hidden', roles.indexOf(role) === -1);
      });
    };
    roleInputs.forEach(function (i) { i.addEventListener('change', applyRole); });
    applyRole();
  }

  /* ---- Masquage automatique des alertes ---- */
  document.querySelectorAll('.alert').forEach(function (a) {
    setTimeout(function () {
      a.style.transition = 'opacity 400ms, transform 400ms, max-height 400ms, margin 400ms, padding 400ms';
      a.style.opacity = '0';
      a.style.transform = 'translateY(-6px)';
      setTimeout(function () { a.remove(); }, 420);
    }, 7000);
  });

  /* ---- Copier dans le presse-papier ---- */
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var text = btn.getAttribute('data-copy');
      if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function () {
          var old = btn.innerHTML;
          btn.innerHTML = '<i class="fas fa-check"></i> Copié';
          setTimeout(function () { btn.innerHTML = old; }, 1800);
        });
      }
    });
  });

  /* ---- Confirmation avant action destructrice ---- */
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  /* ---- Compteur de notifications (rafraîchi toutes les 60 s) ---- */
  var dot = document.querySelector('[data-notif-count]');
  if (dot && dot.dataset.url) {
    setInterval(function () {
      fetch(dot.dataset.url, { headers: { 'x-requested-with': 'XMLHttpRequest' } })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d.count > 0) { dot.textContent = d.count; dot.classList.remove('hidden'); }
          else { dot.classList.add('hidden'); }
        })
        .catch(function () {});
    }, 60000);
  }
})();
