from django.contrib import admin

from .models import Order, OrderEvent, OrderItem


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product_name", "product_price", "quantity", "subtotal", "commission")


class OrderEventInline(admin.TabularInline):
    model = OrderEvent
    extra = 0
    readonly_fields = ("created_at",)


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "user", "total", "status", "is_paid", "created_at")
    list_filter = ("status", "is_paid", "fulfilment")
    search_fields = ("order_number", "user__username", "shipping_phone")
    inlines = (OrderItemInline, OrderEventInline)
    date_hierarchy = "created_at"
    readonly_fields = ("order_number", "subtotal", "commission_total", "total")
