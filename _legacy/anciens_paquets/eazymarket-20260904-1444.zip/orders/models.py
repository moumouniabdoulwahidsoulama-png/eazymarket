"""Commandes de la boutique."""

import secrets
from decimal import Decimal

from django.conf import settings
from django.db import models
from django.utils import timezone

from products.models import Product


class Order(models.Model):
    class Status(models.TextChoices):
        PENDING = "pending", "En attente de paiement"
        PAID = "paid", "Payée"
        PREPARING = "preparing", "En préparation"
        READY = "ready", "Prête"
        SHIPPED = "shipped", "En cours de livraison"
        DELIVERED = "delivered", "Livrée"
        CANCELLED = "cancelled", "Annulée"
        REFUNDED = "refunded", "Remboursée"

    class Fulfilment(models.TextChoices):
        DELIVERY = "delivery", "Livraison à domicile"
        PICKUP = "pickup", "Retrait sur place"

    STATUS_CHOICES = Status.choices  # compatibilité avec l'ancien code

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="orders"
    )
    order_number = models.CharField(max_length=20, unique=True, blank=True)

    subtotal = models.DecimalField("Sous-total", max_digits=12, decimal_places=0, default=0)
    delivery_fee = models.DecimalField("Frais de livraison", max_digits=10, decimal_places=0, default=0)
    total = models.DecimalField(max_digits=12, decimal_places=0, default=0)
    commission_total = models.DecimalField(max_digits=12, decimal_places=0, default=0)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING)
    fulfilment = models.CharField(
        max_length=20, choices=Fulfilment.choices, default=Fulfilment.DELIVERY
    )

    shipping_name = models.CharField("Nom du destinataire", max_length=150, blank=True)
    shipping_address = models.TextField("Adresse / repère")
    shipping_phone = models.CharField("Téléphone", max_length=20)
    shipping_quartier = models.CharField("Quartier", max_length=100, blank=True)
    shipping_city = models.CharField("Ville", max_length=100, default="Ouagadougou")
    shipping_country = models.CharField(max_length=100, default="Burkina Faso")
    country = models.ForeignKey(
        "regions.Country", on_delete=models.PROTECT, null=True, blank=True,
        related_name="orders", verbose_name="Pays",
    )

    delivery_driver = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="deliveries",
        limit_choices_to={"profile__user_type": "delivery"},
    )
    tracking_number = models.CharField(max_length=100, blank=True)
    delivery_notes = models.TextField("Instructions de livraison", blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)

    payment_method = models.CharField(max_length=50, blank=True)
    payment_reference = models.CharField(max_length=60, blank=True)
    is_paid = models.BooleanField(default=False)
    paid_at = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Commande"
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["status", "-created_at"])]

    def __str__(self):
        return f"Commande {self.order_number}"

    def save(self, *args, **kwargs):
        if not self.order_number:
            self.order_number = f"EZ{timezone.now():%y%m}{secrets.token_hex(2).upper()}"
        super().save(*args, **kwargs)

    # ---------- Aides d'affichage ----------
    @property
    def status_badge(self):
        return {
            self.Status.PENDING: "warning",
            self.Status.PAID: "info",
            self.Status.PREPARING: "info",
            self.Status.READY: "info",
            self.Status.SHIPPED: "info",
            self.Status.DELIVERED: "success",
            self.Status.CANCELLED: "danger",
            self.Status.REFUNDED: "neutral",
        }.get(self.status, "neutral")

    @property
    def can_be_cancelled(self):
        return self.status in (self.Status.PENDING, self.Status.PAID)

    @property
    def seller_total(self):
        return self.subtotal - self.commission_total

    def recompute_totals(self):
        items = list(self.items.all())
        self.subtotal = sum((i.subtotal for i in items), Decimal("0"))
        self.commission_total = sum((i.commission for i in items), Decimal("0"))
        self.total = self.subtotal + (self.delivery_fee or 0)
        self.save(update_fields=["subtotal", "commission_total", "total", "updated_at"])
        return self.total


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, blank=True)
    product_name = models.CharField(max_length=200)
    product_price = models.DecimalField(max_digits=12, decimal_places=0)
    quantity = models.PositiveIntegerField()
    subtotal = models.DecimalField(max_digits=12, decimal_places=0)

    seller = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="order_items",
    )
    commission = models.DecimalField(max_digits=12, decimal_places=0, default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Article de commande"
        verbose_name_plural = "Articles de commande"

    def __str__(self):
        return f"{self.quantity}× {self.product_name}"

    @property
    def seller_amount(self):
        return self.subtotal - self.commission


class OrderEvent(models.Model):
    """Historique de suivi visible par le client."""

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="events")
    status = models.CharField(max_length=20, choices=Order.Status.choices)
    note = models.CharField(max_length=250, blank=True)
    by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Étape de commande"
        verbose_name_plural = "Étapes de commande"
        ordering = ["created_at"]

    def __str__(self):
        return f"{self.order.order_number} → {self.get_status_display()}"
