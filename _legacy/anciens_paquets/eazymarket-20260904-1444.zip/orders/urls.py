from django.urls import path

from . import views

urlpatterns = [
    path("validation/", views.checkout, name="checkout"),
    path("mes-commandes/", views.my_orders, name="my_orders"),
    path("vendeur/", views.seller_orders, name="seller_orders"),
    path("livreur/", views.delivery_orders, name="delivery_orders"),
    path("<int:order_id>/", views.order_detail, name="order_detail"),
    path("<int:order_id>/annuler/", views.cancel_order, name="cancel_order"),
    path("<int:order_id>/statut/", views.update_order_status, name="update_order_status"),
]
