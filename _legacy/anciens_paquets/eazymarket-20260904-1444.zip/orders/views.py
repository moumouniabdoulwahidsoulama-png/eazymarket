"""Commandes : validation du panier, suivi, espaces vendeur et livreur."""

from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from cart.models import Cart
from notifications.models import Notification
from payments.models import Transaction
from payments.services import start_transaction
from regions.utils import current_country

from .models import Order, OrderEvent, OrderItem


@login_required
def checkout(request):
    cart, _ = Cart.objects.get_or_create(user=request.user)

    if cart.total_items == 0:
        messages.warning(request, "Votre panier est vide.")
        return redirect("cart")

    issues = cart.has_stock_issue()
    if issues:
        messages.error(
            request,
            "Certains articles ne sont plus disponibles en quantité suffisante. "
            "Ajustez votre panier avant de continuer.",
        )
        return redirect("cart")

    profile = request.user.profile

    if request.method == "POST":
        fulfilment = request.POST.get("fulfilment", Order.Fulfilment.DELIVERY)
        data = {
            "shipping_name": request.POST.get("shipping_name", "").strip(),
            "shipping_phone": request.POST.get("shipping_phone", "").strip(),
            "shipping_address": request.POST.get("shipping_address", "").strip(),
            "shipping_quartier": request.POST.get("shipping_quartier", "").strip(),
            "shipping_city": request.POST.get("shipping_city", "").strip() or "Ouagadougou",
        }
        data.pop("shipping_country", None)
        required = ["shipping_name", "shipping_phone"]
        if fulfilment == Order.Fulfilment.DELIVERY:
            required += ["shipping_address", "shipping_quartier"]

        if any(not data[f] for f in required):
            messages.error(request, "Merci de remplir tous les champs obligatoires.")
            return render(
                request,
                "orders/checkout.html",
                {"cart": cart, "profile": profile, "form": data, "fulfilment": fulfilment},
            )

        with transaction.atomic():
            country = request.user.profile.country or current_country(request)
            order = Order.objects.create(
                user=request.user,
                country=country,
                shipping_country=country.name if country else "Burkina Faso",
                fulfilment=fulfilment,
                delivery_fee=cart.delivery_fee(fulfilment, data["shipping_city"]),
                delivery_notes=request.POST.get("delivery_notes", "").strip(),
                **data,
            )

            for item in cart.items_list:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    product_name=item.product.name,
                    product_price=item.product.price,
                    quantity=item.quantity,
                    subtotal=item.subtotal,
                    seller=item.product.seller,
                    commission=item.commission,
                )

            order.recompute_totals()
            OrderEvent.objects.create(order=order, status=order.status, note="Commande créée")
            cart.items.all().delete()

            tx = start_transaction(
                user=request.user,
                purpose=Transaction.Purpose.ORDER,
                amount=order.total,
                obj=order,
                payer_number=data["shipping_phone"],
            )

        messages.success(request, f"Commande {order.order_number} enregistrée. Dernière étape : le paiement.")
        return redirect("payment_pay", reference=tx.reference)

    initial = {
        "shipping_name": request.user.get_full_name() or request.user.username,
        "shipping_phone": profile.phone,
        "shipping_address": profile.address,
        "shipping_quartier": profile.quartier,
        "shipping_city": profile.city or "Ouagadougou",
    }
    return render(
        request,
        "orders/checkout.html",
        {"cart": cart, "profile": profile, "form": initial, "fulfilment": Order.Fulfilment.DELIVERY},
    )


@login_required
def order_detail(request, order_id):
    order = get_object_or_404(
        Order.objects.prefetch_related("items", "events"), id=order_id, user=request.user
    )
    pending_tx = order.user.transactions.filter(
        object_type="order", object_id=order.id,
        status__in=[Transaction.Status.PENDING, Transaction.Status.AWAITING_REVIEW],
    ).first()
    return render(request, "orders/order_detail.html", {"order": order, "pending_tx": pending_tx})


@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).prefetch_related("items")
    return render(request, "orders/my_orders.html", {"orders": orders})


@login_required
@require_POST
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if not order.can_be_cancelled:
        messages.error(request, "Cette commande ne peut plus être annulée.")
    else:
        order.status = Order.Status.CANCELLED
        order.save(update_fields=["status"])
        OrderEvent.objects.create(
            order=order, status=order.status, note="Annulée par le client", by=request.user
        )
        messages.info(request, "Commande annulée.")
    return redirect("order_detail", order_id=order.id)


# ---------------------------------------------------------------------
# Vendeur
# ---------------------------------------------------------------------
@login_required
def seller_orders(request):
    if not request.user.profile.can_sell:
        return redirect("become_seller")

    items = (
        OrderItem.objects.filter(seller=request.user)
        .select_related("order", "order__user", "product")
        .order_by("-order__created_at")
    )
    grouped = {}
    for item in items:
        grouped.setdefault(item.order_id, {"order": item.order, "items": [], "total": Decimal("0")})
        grouped[item.order_id]["items"].append(item)
        grouped[item.order_id]["total"] += item.seller_amount

    return render(request, "orders/seller_orders.html", {"orders": list(grouped.values())})


# ---------------------------------------------------------------------
# Livreur
# ---------------------------------------------------------------------
@login_required
def delivery_orders(request):
    if not request.user.profile.can_deliver:
        return redirect("become_delivery")
    orders = Order.objects.filter(delivery_driver=request.user)
    return render(request, "orders/delivery_orders.html", {"orders": orders})


@login_required
@require_POST
def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    profile_obj = request.user.profile
    role = profile_obj.user_type

    allowed = False
    if request.user.is_staff:
        allowed = True
    elif profile_obj.can_sell and OrderItem.objects.filter(order=order, seller=request.user).exists():
        allowed = True
    elif profile_obj.can_deliver and order.delivery_driver == request.user:
        allowed = True

    if not allowed:
        messages.error(request, "Vous ne pouvez pas modifier cette commande.")
        return redirect("home")

    new_status = request.POST.get("status")
    if new_status not in dict(Order.Status.choices):
        messages.error(request, "Statut inconnu.")
        return redirect("order_detail", order_id=order.id)

    order.status = new_status
    if new_status == Order.Status.DELIVERED:
        order.delivered_at = timezone.now()
        profile = request.user.profile
        if role == "delivery":
            profile.total_deliveries += 1
            profile.save(update_fields=["total_deliveries"])
    order.save()

    OrderEvent.objects.create(
        order=order, status=new_status, note=request.POST.get("note", ""), by=request.user
    )
    Notification.objects.create(
        user=order.user,
        title=f"Commande {order.order_number}",
        message=f"Statut mis à jour : {order.get_status_display()}",
        link=f"/commandes/{order.id}/",
    )
    messages.success(request, f"Statut mis à jour : {order.get_status_display()}")
    return redirect(request.META.get("HTTP_REFERER", "home"))
