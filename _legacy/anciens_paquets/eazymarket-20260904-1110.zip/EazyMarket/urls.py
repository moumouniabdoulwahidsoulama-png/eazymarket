"""Table de routage principale d'EazyMarket."""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

admin.site.site_header = "Administration EazyMarket"
admin.site.site_title = "EazyMarket"
admin.site.index_title = "Pilotage de la place de marché"

urlpatterns = [
    path("django-admin/", admin.site.urls),
    # Raccourci : /admin/ mène à l'administration Django (habitude de tous les projets)
    path("admin/", RedirectView.as_view(url="/django-admin/", permanent=False)),
    path("compte/", include("accounts.urls")),
    path("panier/", include("cart.urls")),
    path("commandes/", include("orders.urls")),
    path("services/", include("services.urls")),
    path("paiement/", include("payments.urls")),
    path("livraison/", include("delivery.urls")),
    path("notifications/", include("notifications.urls")),
    path("infos/", include("pages.urls")),
    path("pays/", include("regions.urls")),
    path("", include("products.urls")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.BASE_DIR / "static")
