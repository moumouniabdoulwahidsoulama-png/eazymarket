"""
Annule les commandes que les vendeurs n'ont pas confirmées à temps
et rembourse les clients. À lancer toutes les heures.

    python manage.py traiter_commandes
"""

from django.core.management.base import BaseCommand

from orders.services import traiter_les_commandes_expirees


class Command(BaseCommand):
    help = "Annule et rembourse les commandes non confirmées dans le délai."

    def handle(self, *args, **options):
        nombre = traiter_les_commandes_expirees()
        if nombre:
            self.stdout.write(self.style.WARNING(
                f"{nombre} part(s) de commande annulée(s) faute de confirmation. "
                "Les clients ont été remboursés."
            ))
        else:
            self.stdout.write(self.style.SUCCESS("Aucune commande en retard."))
